import xbmc
import xbmcaddon
import time

class RedirectService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.addon = xbmcaddon.Addon()
        self.polling_active = False
        self.check_and_start_polling()

    def check_and_start_polling(self):
        try:
            source_window_id_str = self.addon.getSetting('source_window_id')
            destination_window_id_str = self.addon.getSetting('destination_window_id')
            destination_path = self.addon.getSetting('destination_path')
            
            source_window_id = int(source_window_id_str) if source_window_id_str and source_window_id_str != '0' else None
            destination_window_id = int(destination_window_id_str) if destination_window_id_str and destination_window_id_str != '0' else None

        except (ValueError, TypeError):
            xbmc.log("WindowRedirect: Error - Window IDs must be numbers. Please check your settings.", xbmc.LOGERROR)
            source_window_id = None
            destination_window_id = None

        if not source_window_id or not destination_window_id:
            self.polling_active = False
            xbmc.log("WindowRedirect: Source and destination window IDs must be configured. Polling will not run.", xbmc.LOGINFO)
        else:
            self.polling_active = True
            self.source_window_id = source_window_id
            self.destination_window_id = destination_window_id
            self.destination_path = destination_path
            xbmc.log("WindowRedirect: Settings configured. Polling is now active.", xbmc.LOGINFO)

    def onSettingsChanged(self):
        xbmc.log("WindowRedirect: Add-on settings have changed. Re-evaluating...", xbmc.LOGINFO)
        self.check_and_start_polling()
    
    def onAbortRequested(self):
        return True

    def run(self):
        while not self.abortRequested():
            if self.polling_active:
                if xbmc.getCondVisibility(f"Window.IsVisible({self.source_window_id})"):
                    xbmc.log("WindowRedirect: Correct window is visible. Performing redirection...", xbmc.LOGINFO)
                    
                    xbmc.executebuiltin("Action(Back)")
                    
                    if self.destination_path:
                        xbmc.executebuiltin(f'ActivateWindow({self.destination_window_id}, "{self.destination_path}", return)')
                    else:
                        xbmc.executebuiltin(f'ActivateWindow({self.destination_window_id}, return)')

                    time.sleep(1)
            xbmc.sleep(100)

service = RedirectService()
service.run()